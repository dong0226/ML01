# Sample Environment #

This package contains an OpenAI Gym environment called PushEnv, utilized with PyBullet.  

To test the environment, open a new terminal at the current directory and run the following command
```
python keyboard_test.py
```

# Test History #
The program has undergone comprehensive testing on the Ubuntu 18.04 and Windows 10 operating systems.